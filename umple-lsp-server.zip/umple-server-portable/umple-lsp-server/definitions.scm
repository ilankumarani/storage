; definitions.scm — Maps AST nodes to symbol definitions for indexing.
;
; Used by the LSP server to build the symbol index.
; Capture names follow the pattern: @definition.<kind>
; where <kind> is a SymbolKind ("class", "attribute", "state", etc.)
;
; The LSP walks up from each captured node to find the enclosing
; parent scope (class, statemachine, etc.) for scoped lookups.

; =====================
; TOP-LEVEL DEFINITIONS
; =====================

(class_definition name: (identifier) @definition.class)
(interface_definition name: (identifier) @definition.interface)
(trait_definition name: (identifier) @definition.trait)
(enum_definition name: (identifier) @definition.enum)
(enum_value name: (identifier) @definition.enum_value)
(external_definition name: (identifier) @definition.class)
(association_definition name: (identifier) @definition.association)
(requirement_definition name: (identifier) @definition.requirement)
(requirement_definition name: (req_id) @definition.requirement)
(mixset_definition name: (identifier) @definition.mixset)
(association_class_definition name: (identifier) @definition.class)
(statemachine_definition name: (identifier) @definition.statemachine)

; =====================
; SCOPED DEFINITIONS
; =====================
; These require a parent scope (class, statemachine, etc.)

(attribute_declaration name: (identifier) @definition.attribute)
(enumerated_attribute name: (identifier) @definition.attribute)
(const_declaration name: (identifier) @definition.const)
(method_declaration name: (identifier) @definition.method)
(abstract_method_declaration name: (identifier) @definition.method)
(method_signature name: (identifier) @definition.method)
(trait_method_signature name: (identifier) @definition.method)
(state_machine name: (identifier) @definition.statemachine)
(state name: (identifier) @definition.state)
(referenced_statemachine name: (identifier) @definition.statemachine)
(emit_method name: (identifier) @definition.method)
(template_attribute name: (identifier) @definition.template)
(trace_statement name: (identifier) @definition.tracecase)
